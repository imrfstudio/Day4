import Cocoa

let surname: String = " Lasso"
var score: Double = 0.0
let pi: Double = 3.14159


enum UIStyle {
    case light, dark, system
}

var style = UIStyle.light
style = .dark

let username: String
username = "@iMRFStudio"


print(username)

var cities = ["Kingston", "Ottowa", "Gwelph", "Vancouver", "St. Johns", "Montreal", "Windsor"]
print(cities.count)

let citiesSet = cities
print(citiesSet.count)
